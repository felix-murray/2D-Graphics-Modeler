<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="2d-Graphics-Modler_fr_FR"></TS>
