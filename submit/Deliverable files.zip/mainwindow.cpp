#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "RenderArea.h"


MainWindow::MainWindow(QWidget *parent)
           : QMainWindow(parent)
           , ui(new Ui::MainWindow)
{
    RenderArea renderArea;
    ui->setupUi(this);
    ui->menustack->setCurrentWidget(ui->start_page);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_cancel_button_clicked()
{
    ui->menustack->addWidget(ui->start_page);
    ui->menustack->setCurrentWidget(ui->start_page);
}

void MainWindow::on_polygon_button_clicked()
{
    ui->menustack->addWidget(ui->add_polygon);
    ui->menustack->setCurrentWidget(ui->add_polygon);

}

void MainWindow::on_cancelpoly_button_clicked()
{
    on_cancel_button_clicked();
}

void MainWindow::on_rectangle_button_clicked()
{

    ui->menustack->addWidget(ui->add_rectangle);
    ui->menustack->setCurrentWidget(ui->add_rectangle);

    QComboBox * penColorCombo = new QComboBox(ui->pen_color_box);
    QListView * penColorList    = new QListView(penColorCombo);
    QComboBox * penStyleCombo = new QComboBox(ui->pen_style_box);
    QListView * penStyleList    = new QListView(penColorCombo);

    penColorCombo = comboPenColors(penColorCombo);
    penColorCombo->setView(penColorList);
    penColorCombo->show();

    penStyleCombo = comboPenStyles(penStyleCombo);
    penStyleCombo->setView(penStyleList);
    penStyleCombo->show();
}

void MainWindow::on_build_button_clicked()
{

}

void MainWindow::on_ellipse_button_clicked()
{
    ui->menustack->addWidget(ui->add_ellipse);
    ui->menustack->setCurrentWidget(ui->add_ellipse);
}
void MainWindow::on_cancelellipse_button_clicked()
{
        on_cancel_button_clicked();
}

void MainWindow::on_line_button_clicked()
{
    ui->menustack->addWidget(ui->add_line);
    ui->menustack->setCurrentWidget(ui->add_line);
}
void MainWindow::on_cancelline_button()
{
    on_cancel_button_clicked();
}

void MainWindow::on_polyline_button_clicked()
{
    ui->menustack->addWidget(ui->add_polyline);
    ui->menustack->setCurrentWidget(ui->add_polyline);
}
void MainWindow::on_cancelpolyline_button_clicked()
{
    on_cancel_button_clicked();
}

void MainWindow::on_text_button_clicked()
{
    ui->menustack->addWidget(ui->add_text);
    ui->menustack->setCurrentWidget(ui->add_text);
}
void MainWindow::on_canceltext_button_clicked()
{
        on_cancel_button_clicked();
}



QComboBox * MainWindow::comboPenColors(QComboBox *combo)
{
    combo->addItem("white");
    combo->addItem("black");
    combo->addItem("red");
    combo->addItem("green");
    combo->addItem("blue");
    combo->addItem("cyan");
    combo->addItem("magenta");
    combo->addItem("yellow");
    combo->addItem("gray");
    return combo;
}

QComboBox * MainWindow::comboPenStyles(QComboBox *combo)
{
    combo->addItem("Solid Line");
    combo->addItem("Dash Line");
    combo->addItem("Dot Line");
    combo->addItem("Dash Dot Line");
    combo->addItem("Dash Dot Dot Line");
    combo->addItem("No Pen");
    return combo;
}

